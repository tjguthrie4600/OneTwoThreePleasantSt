Welcome
=======

1. Install scrapy
 * easy_install -U Scrapy (you may need to have root access to install, e.g. sudo)

2. Run the scrapy project
 * cd util/calendar_scraper
 * scrapy crawl calendar -o items.json -t json

3. Find items.json in util/calendar_scraper, full of calendar goodness
